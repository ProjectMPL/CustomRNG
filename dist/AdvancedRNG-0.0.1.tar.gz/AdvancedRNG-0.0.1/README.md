This is a custom random number generator with advanced features including:
-giving you a token for every random number so you can recreate your results